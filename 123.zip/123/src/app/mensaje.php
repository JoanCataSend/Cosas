<?php
$tipo = $_GET['tipo'] ?? 'desconocido';

switch ($tipo) {
    case 'exito':
        $titulo = "¡Éxito!";
        $mensaje = "Tu cuenta ha sido activada correctamente.";
        $clase = "exito";
        break;
    case 'expirado':
        $titulo = "Token expirado";
        $mensaje = "El token ha expirado. Por favor, solicita un nuevo registro.";
        $clase = "error";
        break;
    case 'invalido':
        $titulo = "Token inválido";
        $mensaje = "El token no es válido o ya fue utilizado.";
        $clase = "error";
        break;
    case 'sin_token':
        $titulo = "Error";
        $mensaje = "No se proporcionó un token.";
        $clase = "error";
        break;
    case 'registro_enviado':
        $email = $_GET['email'] ?? '';
        $titulo = "Registro en proceso";
        $mensaje = "Se ha enviado un correo de confirmación a <b>" . htmlspecialchars($email) . "</b>. Revisa tu bandeja de entrada.<br><br>"
            . '<a href="https://ethereal.email/" target="_blank">Ir a Ethereal.email</a>';
        $clase = "info";
        break;
    default:
        $titulo = "Mensaje";
        $mensaje = "Ha ocurrido un error inesperado.";
        $clase = "error";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($titulo) ?></title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        body {
            font-family: sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background: #f9f9f9;
        }
        .mensaje {
            padding: 2em;
            border-radius: 10px;
            text-align: center;
            max-width: 450px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .exito {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .info {
            background-color: #d1ecf1;
            color: #0c5460;
        }
        b {
            font-weight: 600;
        }
    </style>
</head>
<body>
<div class="mensaje <?= htmlspecialchars($clase) ?>">
    <h1><?= htmlspecialchars($titulo) ?></h1>
    <p><?= $mensaje ?></p>
</div>
</body>
</html>
